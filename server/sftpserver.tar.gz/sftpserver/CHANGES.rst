Change History
==============

0.3 (2017-04-09)
----------------
- Use argparse instead of optparse
- Add CHANGES file
- List available auth mechanisms
- Replace Distribute with Setuptools
- Supporting key-based authentication as well

